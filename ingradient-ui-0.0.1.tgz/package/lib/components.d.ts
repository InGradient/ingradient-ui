import * as styled_components_dist_types from 'styled-components/dist/types';
import * as styled_components from 'styled-components';
import * as react from 'react';
import react__default from 'react';
import * as react_jsx_runtime from 'react/jsx-runtime';
import { S as StatusTone, a as alertToneStyles } from './charts-9G47m4fy.js';
export { c as chartPalette } from './charts-9G47m4fy.js';
import * as lucide_react from 'lucide-react';

interface UseZoomPanOptions {
    minZoom?: number;
    maxZoom?: number;
    zoomStep?: number;
}
declare function useZoomPan(options?: UseZoomPanOptions): {
    zoom: number;
    pan: {
        x: number;
        y: number;
    };
    reset: () => void;
    handleWheel: (e: WheelEvent) => void;
    startPan: (clientX: number, clientY: number, currentPanX: number, currentPanY: number) => void;
    movePan: (clientX: number, clientY: number) => boolean;
    endPan: () => void;
    isZoomPanning: () => boolean;
    hasPanned: () => boolean;
};

type SelectionAction = 'toggle' | 'range' | 'single';
declare function useSelection<T extends {
    id: string;
}>(items: T[]): {
    selectedIds: Set<string>;
    lastIndexRef: react.MutableRefObject<number | null>;
    clearSelection: () => void;
    selectAll: (ids?: string[]) => void;
    onSelectionChange: (action: SelectionAction, id: string, rangeStartId?: string) => void;
};

interface UseClipboardOptions {
    /** Duration in ms to keep `copied` true after a successful copy. Default 2000. */
    resetDelay?: number;
}
declare function useClipboard(options?: UseClipboardOptions): {
    copy: (text: string) => Promise<void>;
    copied: boolean;
};

interface UseUndoRedoOptions<T> {
    initialState: T;
    maxHistory?: number;
}
declare function useUndoRedo<T>({ initialState, maxHistory }: UseUndoRedoOptions<T>): {
    state: T;
    setState: (next: T) => void;
    undo: () => void;
    redo: () => void;
    canUndo: boolean;
    canRedo: boolean;
    reset: (newState: T) => void;
};

interface DrawingObject {
    id: string;
    type: 'rect' | 'point';
    x: number;
    y: number;
    w?: number;
    h?: number;
    color?: string;
    label?: string;
}
type DrawingMode = 'cursor' | 'rect' | 'point';
interface DrawingPreview {
    x: number;
    y: number;
    w: number;
    h: number;
}
interface UseDrawingCanvasOptions {
    objects: DrawingObject[];
    mode: DrawingMode;
    minSize?: number;
    handleRadius?: number;
    onObjectsChange: (objects: DrawingObject[]) => void;
    onSelectionChange?: (id: string | null) => void;
}
declare function useDrawingCanvas({ objects, mode, minSize, handleRadius, onObjectsChange, onSelectionChange, }: UseDrawingCanvasOptions): {
    selectedId: string | null;
    drawingPreview: DrawingPreview | null;
    cursor: string;
    bindings: {
        onMouseDown: (e: React.MouseEvent) => void;
        onMouseMove: (e: React.MouseEvent) => void;
        onMouseUp: () => void;
        onMouseLeave: () => void;
    };
};

type ButtonVariant = 'solid' | 'secondary' | 'accent';
type LegacyButtonVariant = 'primary' | 'ghost' | 'accent';
type ButtonSize = 'sm' | 'md' | 'lg';
type ButtonTone = 'default' | 'danger';
type ButtonProps = react__default.ButtonHTMLAttributes<HTMLButtonElement> & {
    variant?: ButtonVariant;
    $variant?: LegacyButtonVariant;
    size?: ButtonSize;
    tone?: ButtonTone;
    leadingIcon?: react__default.ReactNode;
    trailingIcon?: react__default.ReactNode;
};
declare const buttonPadding: {
    readonly sm: "8px 12px";
    readonly md: "10px 14px";
    readonly lg: "12px 18px";
};
declare function normalizeVariant(variant?: ButtonVariant, legacyVariant?: LegacyButtonVariant): ButtonVariant;

declare function Button({ variant, $variant, size, tone, leadingIcon, trailingIcon, children, ...props }: ButtonProps): react_jsx_runtime.JSX.Element;

declare function IconButton({ variant, $variant, size, tone, children, ...props }: ButtonProps): react_jsx_runtime.JSX.Element;

declare const TextField: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react__default.DetailedHTMLProps<react__default.InputHTMLAttributes<HTMLInputElement>, HTMLInputElement>, never>> & string;
declare const TextareaField: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react__default.DetailedHTMLProps<react__default.TextareaHTMLAttributes<HTMLTextAreaElement>, HTMLTextAreaElement>, never>> & string;
declare function PasswordField(props: react__default.InputHTMLAttributes<HTMLInputElement>): react_jsx_runtime.JSX.Element;

interface SearchFieldProps extends Omit<react__default.InputHTMLAttributes<HTMLInputElement>, 'type' | 'size'> {
    onClear?: () => void;
    size?: 'sm' | 'md';
}
declare function SearchField({ onClear, size, value, ...rest }: SearchFieldProps): react_jsx_runtime.JSX.Element;

interface NumberFieldProps {
    value: number;
    onChange: (v: number) => void;
    min?: number;
    max?: number;
    step?: number;
    disabled?: boolean;
    placeholder?: string;
    format?: (v: number) => string;
    className?: string;
    id?: string;
}
declare function NumberField({ value, onChange, min, max, step, disabled, placeholder, format, className, id, }: NumberFieldProps): react_jsx_runtime.JSX.Element;

interface MentionCandidate {
    id: string;
    name: string;
    secondary?: string;
}
interface MentionTextareaProps {
    value: string;
    onChange: (value: string) => void;
    candidates: MentionCandidate[];
    onSubmit?: (text: string, mentionIds: string[]) => void;
    placeholder?: string;
    maxLength?: number;
    disabled?: boolean;
    className?: string;
    triggerChar?: string;
}
declare function MentionTextarea({ value, onChange, candidates, onSubmit, placeholder, maxLength, disabled, className, triggerChar, }: MentionTextareaProps): react_jsx_runtime.JSX.Element;

declare function Checkbox({ label, ...props }: react__default.InputHTMLAttributes<HTMLInputElement> & {
    label?: react__default.ReactNode;
}): react_jsx_runtime.JSX.Element;
declare function Radio({ label, ...props }: react__default.InputHTMLAttributes<HTMLInputElement> & {
    label?: react__default.ReactNode;
}): react_jsx_runtime.JSX.Element;
declare function Switch({ checked, label, ...props }: Omit<react__default.InputHTMLAttributes<HTMLInputElement>, 'type'> & {
    label?: react__default.ReactNode;
}): react_jsx_runtime.JSX.Element;

declare function FileInput({ onFiles, accept, multiple, label, }: {
    onFiles: (files: File[]) => void;
    accept?: string;
    multiple?: boolean;
    label?: react__default.ReactNode;
}): react_jsx_runtime.JSX.Element;

type SelectFieldProps = react__default.SelectHTMLAttributes<HTMLSelectElement>;
declare function SelectField({ children, value, defaultValue, onChange, disabled, className, style, name, id, required, autoFocus, ...props }: SelectFieldProps): react_jsx_runtime.JSX.Element;

interface DropdownOption {
    value: string;
    label: string;
    description?: string;
}

declare function DropdownSelect({ value, options, onChange, disabled, }: {
    value: string;
    options: DropdownOption[];
    onChange: (value: string) => void;
    disabled?: boolean;
}): react_jsx_runtime.JSX.Element;

interface UploadDropzoneProps {
    accept?: string;
    multiple?: boolean;
    onFiles: (files: File[]) => void;
    disabled?: boolean;
    children?: react__default.ReactNode;
    className?: string;
}
declare function UploadDropzone({ accept, multiple, onFiles, disabled, children, className, }: UploadDropzoneProps): react_jsx_runtime.JSX.Element;

interface CopyButtonProps {
    value: string;
    children?: react__default.ReactNode;
    copiedLabel?: string;
    size?: 'sm' | 'md';
    className?: string;
}
declare function CopyButton({ value, children, copiedLabel, size, className, }: CopyButtonProps): react_jsx_runtime.JSX.Element;

interface ModeSwitcherOption {
    value: string;
    label: string;
    icon?: react__default.ReactNode;
}
interface ModeSwitcherProps {
    options: ModeSwitcherOption[];
    value: string;
    onChange: (value: string) => void;
    size?: 'sm' | 'md';
    className?: string;
}
declare function ModeSwitcher({ options, value, onChange, size, className }: ModeSwitcherProps): react_jsx_runtime.JSX.Element;

interface FormGroupProps {
    title?: string;
    description?: string;
    children: react__default.ReactNode;
    className?: string;
}
declare function FormGroup({ title, description, children, className }: FormGroupProps): react_jsx_runtime.JSX.Element;
interface FieldRowProps {
    label: string;
    htmlFor?: string;
    hint?: string;
    children: react__default.ReactNode;
}
declare function FieldRow({ label, htmlFor, hint, children }: FieldRowProps): react_jsx_runtime.JSX.Element;

interface FilterBarLayoutProps {
    onClear?: () => void;
    clearLabel?: string;
    children: react__default.ReactNode;
    className?: string;
}
declare function FilterBarLayout({ onClear, clearLabel, children, className }: FilterBarLayoutProps): react_jsx_runtime.JSX.Element;

declare const SmallText: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, never>> & string;
/** @deprecated Use `EmptyState` from `empty-state` instead */
declare const EmptyStateText: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const LoadingState: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | react.RefObject<HTMLDivElement> | null | undefined;
}, never>> & string;
declare const ErrorState: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | react.RefObject<HTMLDivElement> | null | undefined;
}, never>> & string;
declare const StatusPill: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<react.DetailedHTMLProps<react.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, {
    $tone?: StatusTone;
    tone?: StatusTone;
}>> & string;

declare const badgeTone: {
    readonly neutral: "var(--ig-color-badge-neutral)";
    readonly accent: "var(--ig-color-badge-accent)";
    readonly success: "var(--ig-color-badge-success)";
    readonly warning: "var(--ig-color-badge-warning)";
    readonly danger: "var(--ig-color-badge-danger)";
};
declare const Badge: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<react.DetailedHTMLProps<react.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, {
    $tone?: keyof typeof badgeTone;
}>> & string;
declare const Chip: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, "$tone"> & {
    $tone?: keyof typeof badgeTone;
}, "ref"> & {
    ref?: ((instance: HTMLSpanElement | null) => void | react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | react.RefObject<HTMLSpanElement> | null | undefined;
}, never>> & string;
declare function Avatar({ src, alt, initials, size, }: {
    src?: string;
    alt?: string;
    initials?: string;
    size?: number;
}): react_jsx_runtime.JSX.Element;

declare function NotificationBadge({ children, value, hidden, tone, className, style, }: {
    children: react__default.ReactNode;
    value?: react__default.ReactNode;
    hidden?: boolean;
    tone?: 'accent' | 'danger';
    className?: string;
    style?: react__default.CSSProperties;
}): react_jsx_runtime.JSX.Element;

declare const ProgressTrack: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const ProgressFill: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, {
    $value: number;
}>> & string;
declare function ProgressBar({ value }: {
    value: number;
}): react_jsx_runtime.JSX.Element;

declare const Skeleton: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, {
    $height?: string;
}>> & string;

declare const Alert: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, {
    $tone?: keyof typeof alertToneStyles;
}>> & string;
declare const InlineMessage: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "$tone"> & {
    $tone?: keyof typeof alertToneStyles;
}, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | react.RefObject<HTMLDivElement> | null | undefined;
}, never>> & string;

declare const sizeMap: {
    readonly sm: 14;
    readonly md: 18;
    readonly lg: 24;
};
declare const toneColorMap: {
    readonly accent: "var(--ig-color-accent)";
    readonly white: "var(--ig-color-text-primary)";
    readonly muted: "var(--ig-color-text-soft)";
};
type SpinnerSize = keyof typeof sizeMap;
type SpinnerTone = keyof typeof toneColorMap;
interface SpinnerProps extends Omit<react__default.HTMLAttributes<HTMLSpanElement>, 'children'> {
    /** Spinner 크기. sm=14px, md=18px, lg=24px */
    size?: SpinnerSize;
    /** 색상 tone. accent=브랜드 색, white=텍스트 primary, muted=텍스트 soft */
    tone?: SpinnerTone;
}
declare function Spinner({ size, tone, 'aria-label': ariaLabel, ...rest }: SpinnerProps): react_jsx_runtime.JSX.Element;

type ToastTone = keyof typeof alertToneStyles;
interface ToastItem {
    id: string;
    message: react__default.ReactNode;
    tone?: ToastTone;
    duration?: number;
}
type ToastFn = (message: react__default.ReactNode, opts?: {
    tone?: ToastTone;
    duration?: number;
}) => void;
declare function useToast(): ToastFn;
declare function ToastProvider({ children }: {
    children: react__default.ReactNode;
}): react_jsx_runtime.JSX.Element;

interface SelectionActionBarProps {
    selectedCount: number;
    totalCount?: number;
    onClearSelection: () => void;
    onSelectAll?: () => void;
    selectAllLabel?: string;
    actions?: react__default.ReactNode;
    className?: string;
}
declare function SelectionActionBar({ selectedCount, totalCount, onClearSelection, onSelectAll, selectAllLabel, actions, className, }: SelectionActionBarProps): react_jsx_runtime.JSX.Element | null;

interface EmptyStateProps {
    icon?: react__default.ReactNode;
    title?: string;
    description?: string;
    action?: {
        label: string;
        onClick: () => void;
    };
    className?: string;
    children?: react__default.ReactNode;
}
declare function EmptyState({ icon, title, description, action, className, children }: EmptyStateProps): react_jsx_runtime.JSX.Element;

declare function Tabs({ items, value, onChange, variant, className, style, }: {
    items: Array<{
        value: string;
        label: string;
    }>;
    value: string;
    onChange: (value: string) => void;
    variant?: 'pill' | 'underline';
    className?: string;
    style?: react__default.CSSProperties;
}): react_jsx_runtime.JSX.Element;
declare const TabsNav: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react__default.DetailedHTMLProps<react__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;

type VerticalTabsRadius = 'xs' | 'sm' | 'md' | 'lg';

type VerticalTabsItem = {
    value: string;
    label: react__default.ReactNode;
    badge?: react__default.ReactNode;
    icon?: react__default.ReactNode;
    disabled?: boolean;
};
declare function VerticalTabs({ items, value, onChange, radius, className, style, }: {
    items: VerticalTabsItem[];
    value: string;
    onChange: (value: string) => void;
    radius?: VerticalTabsRadius;
    className?: string;
    style?: react__default.CSSProperties;
}): react_jsx_runtime.JSX.Element;

declare function Breadcrumbs({ items, }: {
    items: Array<{
        label: string;
        href?: string;
    }>;
}): react_jsx_runtime.JSX.Element;

declare function Pagination({ page, totalPages, onChange, }: {
    page: number;
    totalPages: number;
    onChange: (page: number) => void;
}): react_jsx_runtime.JSX.Element;

declare function Stepper({ steps, activeStep, }: {
    steps: string[];
    activeStep: number;
}): react_jsx_runtime.JSX.Element;

declare const ModalBackdrop: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const ModalCard: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const CompactModalCard: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | react.RefObject<HTMLDivElement> | null | undefined;
}, never>> & string;
declare const ModalHeader: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const ModalTitle: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, never>> & string;
declare const ModalActions: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const Drawer: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<react.DetailedHTMLProps<react.HTMLAttributes<HTMLElement>, HTMLElement>, {
    $side?: "left" | "right";
}>> & string;

declare const PopoverCard: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const Menu: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const MenuPopover: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | react.RefObject<HTMLDivElement> | null | undefined;
}, never>> & string;
declare const TooltipBubble: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const HoverCard: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | react.RefObject<HTMLDivElement> | null | undefined;
}, never>> & string;

declare function DialogCloseButton({ 'aria-label': ariaLabel, title, children, ...props }: react__default.ComponentProps<typeof IconButton>): react_jsx_runtime.JSX.Element;

declare function DialogShell({ title, description, children, actions, onClose, width, }: {
    title: react__default.ReactNode;
    description?: react__default.ReactNode;
    children?: react__default.ReactNode;
    actions?: react__default.ReactNode;
    onClose?: () => void;
    width?: string | number;
}): react_jsx_runtime.JSX.Element;
declare function ConfirmDialog({ title, description, confirmLabel, cancelLabel, onConfirm, onCancel, confirmVariant, danger, }: {
    title: react__default.ReactNode;
    description: react__default.ReactNode;
    confirmLabel?: react__default.ReactNode;
    cancelLabel?: react__default.ReactNode;
    onConfirm: () => void;
    onCancel: () => void;
    confirmVariant?: ButtonVariant;
    danger?: boolean;
}): react_jsx_runtime.JSX.Element;

/** click-outside 처리를 위한 투명 backdrop */
declare const ContextMenuBackdrop: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
/** cursor 위치에 fixed 배치되는 메뉴 컨테이너 */
declare const ContextMenuList: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<styled_components_dist_types.Substitute<styled_components_dist_types.Substitute<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, Omit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | react.RefObject<HTMLDivElement> | null | undefined;
}>, {
    $x: number;
    $y: number;
}>, {
    $x: number;
    $y: number;
}>> & string;
/** 하위 메뉴(서브메뉴)를 감싸는 wrapper — hover 감지를 위해 position: relative를 제공 */
declare const ContextMenuItem: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
/** 메뉴 항목 버튼. $danger=true 이면 destructive 색상 적용 */
declare const ContextMenuButton: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<react.DetailedHTMLProps<react.ButtonHTMLAttributes<HTMLButtonElement>, HTMLButtonElement>, {
    $danger?: boolean;
}>> & string;
/** cursor 위치에 fixed 배치되는 서브메뉴 컨테이너 */
declare const ContextMenuSub: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<styled_components_dist_types.Substitute<styled_components_dist_types.Substitute<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, Omit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | react.RefObject<HTMLDivElement> | null | undefined;
}>, {
    $left: number;
    $top: number;
}>, {
    $left: number;
    $top: number;
}>> & string;
/** 서브메뉴 내 항목 버튼. $color로 개별 색상 지정 가능 */
declare const ContextMenuSubItem: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<react.DetailedHTMLProps<react.ButtonHTMLAttributes<HTMLButtonElement>, HTMLButtonElement>, {
    $color?: string;
}>> & string;

interface TooltipProps {
    /** Tooltip text or node shown on hover */
    content: react__default.ReactNode;
    /** The element that triggers the tooltip */
    children: react__default.ReactNode;
    /** Gap between trigger bottom and tooltip top (px). Default: 6 */
    gap?: number;
}
declare const Tooltip: react__default.FC<TooltipProps>;

declare function Table<T extends {
    id?: string | number;
}>({ columns, rows, }: {
    columns: Array<{
        key: string;
        header: string;
        render: (row: T) => react__default.ReactNode;
    }>;
    rows: T[];
}): react_jsx_runtime.JSX.Element;
declare const DataGrid: typeof Table;

declare const SectionPanel: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLElement>, HTMLElement>, never>> & string;
declare const ActionBar: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;

declare function ImageGrid<T extends {
    id?: string | number;
}>({ items, getImageSrc, getTitle, getDescription, getMeta, minItemWidth, selectedIds, onItemClick, }: {
    items: T[];
    getImageSrc: (item: T) => string;
    getTitle?: (item: T) => react__default.ReactNode;
    getDescription?: (item: T) => react__default.ReactNode;
    getMeta?: (item: T) => react__default.ReactNode;
    minItemWidth?: number;
    selectedIds?: Array<string | number>;
    onItemClick?: (item: T) => void;
}): react_jsx_runtime.JSX.Element;

declare function StatCard({ label, value, hint, meta, }: {
    label: react__default.ReactNode;
    value: react__default.ReactNode;
    hint?: react__default.ReactNode;
    meta?: react__default.ReactNode;
}): react_jsx_runtime.JSX.Element;
declare const MetricCard: typeof StatCard;

declare function ProgressBlock({ label, value, hint, }: {
    label: react__default.ReactNode;
    value: number;
    hint?: react__default.ReactNode;
}): react_jsx_runtime.JSX.Element;

declare function PreviewCard({ title, description, imageSrc, meta, actions, }: {
    title: react__default.ReactNode;
    description?: react__default.ReactNode;
    imageSrc: string;
    meta?: react__default.ReactNode;
    actions?: react__default.ReactNode;
}): react_jsx_runtime.JSX.Element;

declare function AssignmentRow({ title, description, meta, control, }: {
    title: react__default.ReactNode;
    description?: react__default.ReactNode;
    meta?: react__default.ReactNode;
    control?: react__default.ReactNode;
}): react_jsx_runtime.JSX.Element;

type ColorSwatchSize = 'xs' | 'sm' | 'md';
type ColorSwatchShape = 'circle' | 'square';
declare const ColorSwatch: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<react.DetailedHTMLProps<react.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, {
    $color: string;
    $size?: ColorSwatchSize;
    $shape?: ColorSwatchShape;
}>> & string;

interface CommentItemProps {
    author: string;
    timestamp?: string;
    body: string;
    actions?: react__default.ReactNode;
}
declare function CommentItem({ author, timestamp, body, actions }: CommentItemProps): react_jsx_runtime.JSX.Element;
interface CommentThreadProps {
    children: react__default.ReactNode;
    className?: string;
}
declare function CommentThread({ children, className }: CommentThreadProps): react_jsx_runtime.JSX.Element;
interface CommentInputProps {
    value: string;
    onChange: (value: string) => void;
    onSubmit?: () => void;
    placeholder?: string;
    submitLabel?: string;
    disabled?: boolean;
    maxLength?: number;
}
declare function CommentInput({ value, onChange, onSubmit, placeholder, submitLabel, disabled, maxLength, }: CommentInputProps): react_jsx_runtime.JSX.Element;

interface TagItemData {
    id: string;
    color: string;
    label: string;
    count?: number;
}
interface TagListProps {
    items: TagItemData[];
    selectedId?: string | null;
    activeIds?: Set<string>;
    onItemClick?: (id: string) => void;
    className?: string;
}
declare function TagList({ items, selectedId, activeIds, onItemClick, className }: TagListProps): react_jsx_runtime.JSX.Element;

interface TagSearchCandidate {
    id: string;
    color: string;
    label: string;
}
interface TagListSearchProps {
    placeholder?: string;
    candidates: TagSearchCandidate[];
    onSelect: (id: string) => void;
    emptyMessage?: string;
    emptyAction?: {
        label: string;
        onClick: () => void;
    };
    className?: string;
}
declare function TagListSearch({ placeholder, candidates, onSelect, emptyMessage, emptyAction, className, }: TagListSearchProps): react_jsx_runtime.JSX.Element;

interface ImageViewerProps {
    src: string;
    alt?: string;
    zoomOptions?: UseZoomPanOptions;
    onZoomChange?: (zoom: number) => void;
    /** Overlay layer (e.g. DrawingLayer) rendered on top of the image */
    children?: react__default.ReactNode;
    className?: string;
}
declare function ImageViewer({ src, alt, zoomOptions, onZoomChange, children, className, }: ImageViewerProps): react_jsx_runtime.JSX.Element;

interface ImageViewerToolbarProps {
    zoom: number;
    onZoomIn: () => void;
    onZoomOut: () => void;
    onReset: () => void;
    /** Extra tool buttons slot */
    children?: react__default.ReactNode;
    className?: string;
}
declare function ImageViewerToolbar({ zoom, onZoomIn, onZoomOut, onReset, children, className, }: ImageViewerToolbarProps): react_jsx_runtime.JSX.Element;

interface DrawingLayerProps {
    objects: DrawingObject[];
    selectedId?: string | null;
    drawingPreview?: DrawingPreview | null;
    showHandles?: boolean;
    showLabels?: boolean;
    showCrosshair?: boolean;
    cursorX?: number;
    cursorY?: number;
}
declare function DrawingLayer({ objects, selectedId, drawingPreview, showHandles, showLabels, showCrosshair, cursorX, cursorY, }: DrawingLayerProps): react_jsx_runtime.JSX.Element;

interface ResizablePanelProps {
    direction?: 'horizontal' | 'vertical';
    defaultSize?: number;
    minSize?: number;
    maxSize?: number;
    storageKey?: string;
    children: [react__default.ReactNode, react__default.ReactNode];
    className?: string;
}
declare function ResizablePanel({ direction, defaultSize, minSize, maxSize, storageKey, children, className, }: ResizablePanelProps): react_jsx_runtime.JSX.Element;

interface ChipGroupItem {
    id: string;
    label: string;
    color?: string;
}
interface ChipGroupProps {
    items: ChipGroupItem[];
    maxVisible?: number;
    onItemClick?: (id: string) => void;
    className?: string;
}
declare function ChipGroup({ items, maxVisible, onItemClick, className }: ChipGroupProps): react_jsx_runtime.JSX.Element;

interface KeyboardShortcutHintProps {
    keys: string[];
    size?: 'sm' | 'md';
    className?: string;
}
declare function KeyboardShortcutHint({ keys, size, className }: KeyboardShortcutHintProps): react_jsx_runtime.JSX.Element;

declare const icons: {
    readonly activity: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly alertCircle: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly barChart3: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly camera: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly checkCircle: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly chevronRight: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly fileText: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly filter: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly globe: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly grid3x3: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly image: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly info: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly layers: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly layoutGrid: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly lineChart: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly maximize: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly pieChart: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly qrCode: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly refreshCw: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly search: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly settings: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly shuffle: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly table: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly wifi: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly wifiOff: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
    readonly x: react.ForwardRefExoticComponent<Omit<lucide_react.LucideProps, "ref"> & react.RefAttributes<SVGSVGElement>>;
};
type IconName = keyof typeof icons;

declare function IconGallery({ names, size, }: {
    names?: IconName[];
    size?: number;
}): react_jsx_runtime.JSX.Element;

interface CartesianSeries {
    key: string;
    label: string;
    color?: string;
}
interface PieDatum {
    name: string;
    value: number;
    color?: string;
}

declare function ChartLegend({ items, }: {
    items: Array<{
        label: string;
        color: string;
    }>;
}): react_jsx_runtime.JSX.Element;

declare function ChartTooltipContent({ active, label, payload, }: {
    active?: boolean;
    label?: string;
    payload?: Array<{
        name?: string;
        value?: string | number;
        color?: string;
    }>;
}): react_jsx_runtime.JSX.Element | null;

declare function ChartContainer({ title, description, height, loading, empty, emptyMessage, legend, children, }: {
    title: string;
    description?: string;
    height?: number;
    loading?: boolean;
    empty?: boolean;
    emptyMessage?: string;
    legend?: react__default.ReactNode;
    children: react__default.ReactNode;
}): react_jsx_runtime.JSX.Element;

declare function LineChartCard<T extends Record<string, string | number>>({ title, description, data, series, xKey, height, loading, }: {
    title: string;
    description?: string;
    data: T[];
    series: CartesianSeries[];
    xKey: keyof T & string;
    height?: number;
    loading?: boolean;
}): react_jsx_runtime.JSX.Element;

declare function BarChartCard<T extends Record<string, string | number>>({ title, description, data, series, xKey, height, loading, }: {
    title: string;
    description?: string;
    data: T[];
    series: CartesianSeries[];
    xKey: keyof T & string;
    height?: number;
    loading?: boolean;
}): react_jsx_runtime.JSX.Element;

declare function PieChartCard({ title, description, data, height, loading, }: {
    title: string;
    description?: string;
    data: PieDatum[];
    height?: number;
    loading?: boolean;
}): react_jsx_runtime.JSX.Element;

declare const Paper: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const Card: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const Accordion: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.DetailsHTMLAttributes<HTMLDetailsElement>, HTMLDetailsElement>, never>> & string;

export { Accordion, ActionBar, Alert, AssignmentRow, Avatar, Badge, BarChartCard, Breadcrumbs, Button, type ButtonProps, type ButtonSize, type ButtonTone, type ButtonVariant, Card, type CartesianSeries, ChartContainer, ChartLegend, ChartTooltipContent, Checkbox, Chip, ChipGroup, type ChipGroupItem, type ChipGroupProps, ColorSwatch, type ColorSwatchShape, type ColorSwatchSize, CommentInput, type CommentInputProps, CommentItem, type CommentItemProps, CommentThread, type CommentThreadProps, CompactModalCard, ConfirmDialog, ContextMenuBackdrop, ContextMenuButton, ContextMenuItem, ContextMenuList, ContextMenuSub, ContextMenuSubItem, CopyButton, type CopyButtonProps, DataGrid, DialogCloseButton, DialogShell, Drawer, DrawingLayer, type DrawingLayerProps, type DrawingMode, type DrawingObject, type DrawingPreview, type DropdownOption, DropdownSelect, EmptyState, type EmptyStateProps, EmptyStateText, ErrorState, FieldRow, type FieldRowProps, FileInput, FilterBarLayout, type FilterBarLayoutProps, FormGroup, type FormGroupProps, HoverCard, IconButton, IconGallery, type IconName, ImageGrid, ImageViewer, type ImageViewerProps, ImageViewerToolbar, type ImageViewerToolbarProps, InlineMessage, KeyboardShortcutHint, type KeyboardShortcutHintProps, type LegacyButtonVariant, LineChartCard, LoadingState, type MentionCandidate, MentionTextarea, type MentionTextareaProps, Menu, MenuPopover, MetricCard, ModalActions, ModalBackdrop, ModalCard, ModalHeader, ModalTitle, ModeSwitcher, type ModeSwitcherOption, type ModeSwitcherProps, NotificationBadge, NumberField, type NumberFieldProps, Pagination, Paper, PasswordField, PieChartCard, type PieDatum, PopoverCard, PreviewCard, ProgressBar, ProgressBlock, ProgressFill, ProgressTrack, Radio, ResizablePanel, type ResizablePanelProps, SearchField, type SearchFieldProps, SectionPanel, SelectField, type SelectFieldProps, type SelectionAction, SelectionActionBar, type SelectionActionBarProps, Skeleton, SmallText, Spinner, type SpinnerProps, type SpinnerSize, type SpinnerTone, StatCard, StatusPill, StatusTone, Stepper, Switch, Table, Tabs, TabsNav, type TagItemData, TagList, type TagListProps, TagListSearch, type TagListSearchProps, type TagSearchCandidate, TextField, TextareaField, type ToastItem, ToastProvider, type ToastTone, Tooltip, TooltipBubble, type TooltipProps, UploadDropzone, type UploadDropzoneProps, type UseClipboardOptions, type UseDrawingCanvasOptions, type UseUndoRedoOptions, type UseZoomPanOptions, VerticalTabs, type VerticalTabsItem, type VerticalTabsRadius, buttonPadding, icons, normalizeVariant, useClipboard, useDrawingCanvas, useSelection, useToast, useUndoRedo, useZoomPan };
