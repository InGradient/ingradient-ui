import * as styled_components from 'styled-components';

declare const appShell: styled_components.RuleSet<object>;
declare const headerSurface: styled_components.RuleSet<object>;
declare const pageHeaderSurface: styled_components.RuleSet<object>;
declare const pageContentLayout: styled_components.RuleSet<object>;

export { appShell as a, pageHeaderSurface as b, headerSurface as h, pageContentLayout as p };
