export { b as buttonAccent, a as buttonDanger, c as buttonDangerSecondary, d as buttonPrimary, e as buttonSecondary, f as controlField, s as surfaceCard, g as surfacePanel, h as surfaceRaised, i as surfaceRounded } from './buttons-CsntCuGx.js';
import * as react_jsx_runtime from 'react/jsx-runtime';
import react__default from 'react';
import * as styled_components_dist_types from 'styled-components/dist/types';
import * as styled_components from 'styled-components';

type Space = number | string;
declare function space(value?: Space): string | undefined;
declare function numberOrString(value?: number | string): string | undefined;

type BoxProps = react__default.HTMLAttributes<HTMLDivElement> & {
    display?: string;
    padding?: Space;
    gap?: Space;
    width?: string | number;
    height?: string | number;
    align?: string;
    justify?: string;
    direction?: string;
    wrap?: string;
};
declare function Box({ display, padding, gap, width, height, align, justify, direction, wrap, ...props }: BoxProps): react_jsx_runtime.JSX.Element;

declare function Stack({ gap, align, justify, ...props }: react__default.HTMLAttributes<HTMLDivElement> & {
    gap?: Space;
    align?: string;
    justify?: string;
}): react_jsx_runtime.JSX.Element;
declare function Inline({ gap, align, justify, wrap, ...props }: react__default.HTMLAttributes<HTMLDivElement> & {
    gap?: Space;
    align?: string;
    justify?: string;
    wrap?: string;
}): react_jsx_runtime.JSX.Element;
declare function Grid({ gap, columns, minItemWidth, ...props }: react__default.HTMLAttributes<HTMLDivElement> & {
    gap?: Space;
    columns?: string;
    minItemWidth?: string | number;
}): react_jsx_runtime.JSX.Element;
declare function Container({ maxWidth, padding, ...props }: react__default.HTMLAttributes<HTMLDivElement> & {
    maxWidth?: string | number;
    padding?: Space;
}): react_jsx_runtime.JSX.Element;

declare const toneColor: {
    readonly default: "var(--ig-color-text-primary)";
    readonly secondary: "var(--ig-color-text-secondary)";
    readonly muted: "var(--ig-color-text-muted)";
    readonly soft: "var(--ig-color-text-soft)";
    readonly accent: "var(--ig-color-accent-soft)";
    readonly success: "var(--ig-color-status-running-text)";
    readonly warning: "var(--ig-color-status-draft-text)";
    readonly danger: "var(--ig-color-status-failed-text)";
};
declare function Text({ tone, size, weight, ...props }: react__default.HTMLAttributes<HTMLSpanElement> & {
    tone?: keyof typeof toneColor;
    size?: string;
    weight?: number;
}): react_jsx_runtime.JSX.Element;

declare function Heading({ level, ...props }: react__default.HTMLAttributes<HTMLHeadingElement> & {
    level?: 1 | 2 | 3 | 4;
}): react_jsx_runtime.JSX.Element;

declare function Surface({ elevation, radius, ...props }: react__default.HTMLAttributes<HTMLDivElement> & {
    elevation?: 'panel' | 'raised' | 'card';
    radius?: Space;
}): react_jsx_runtime.JSX.Element;

declare const Divider: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react__default.DetailedHTMLProps<react__default.HTMLAttributes<HTMLHRElement>, HTMLHRElement>, never>> & string;
declare const ScrollArea: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react__default.DetailedHTMLProps<react__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare function Icon({ size, ...props }: react__default.HTMLAttributes<HTMLSpanElement> & {
    size?: number;
}): react_jsx_runtime.JSX.Element;

export { Box, type BoxProps, Container, Divider, Grid, Heading, Icon, Inline, ScrollArea, type Space, Stack, Surface, Text, numberOrString, space };
