export { a as appShell, h as headerSurface, p as pageContentLayout, b as pageHeaderSurface } from './patterns-CvIAZkYq.js';
import * as styled_components_dist_types from 'styled-components/dist/types';
import * as styled_components from 'styled-components';
import * as react from 'react';
import react__default from 'react';
import * as react_jsx_runtime from 'react/jsx-runtime';

declare const AppShell: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const PageHeader: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLElement>, HTMLElement>, never>> & string;
declare const PageHeaderRow: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const PageTitleBlock: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const PageTitle: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, never>> & string;
declare const PageSubtitle: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLParagraphElement>, HTMLParagraphElement>, never>> & string;
declare const PageContent: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const Panel: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLElement>, HTMLElement>, never>> & string;
declare const PanelHeader: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const PanelTitle: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, never>> & string;
declare const PanelHint: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, never>> & string;
declare const SectionTitle: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, never>> & string;
declare const Toolbar: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const FilterBar: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>, "ref"> & {
    ref?: ((instance: HTMLDivElement | null) => void | react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | react.RefObject<HTMLDivElement> | null | undefined;
}, never>> & string;
declare const FormSection: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<Omit<styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLElement>, HTMLElement>, never>, "ref"> & {
    ref?: ((instance: HTMLElement | null) => void | react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | react.RefObject<HTMLElement> | null | undefined;
}, never>> & string;
declare const FieldGroup: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const FieldLabel: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.LabelHTMLAttributes<HTMLLabelElement>, HTMLLabelElement>, never>> & string;
declare const FieldHint: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, never>> & string;

declare function SplitLayout({ sidebar, content, inspector, sidebarWidth, inspectorWidth, }: {
    sidebar?: react__default.ReactNode;
    content: react__default.ReactNode;
    inspector?: react__default.ReactNode;
    sidebarWidth?: string;
    inspectorWidth?: string;
}): react_jsx_runtime.JSX.Element;
declare const DashboardGrid: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react__default.DetailedHTMLProps<react__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const ListDetailLayout: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react__default.DetailedHTMLProps<react__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const SettingsShell: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react__default.DetailedHTMLProps<react__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const SplitPanelShell: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react__default.DetailedHTMLProps<react__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const InspectorLayout: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react__default.DetailedHTMLProps<react__default.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;

declare const SidebarNav: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLElement>, HTMLElement>, never>> & string;
declare const AppSidebar: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<react.DetailedHTMLProps<react.HTMLAttributes<HTMLElement>, HTMLElement>, {
    $width?: number | string;
}>> & string;
declare const SidebarSection: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const SidebarFooter: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const TopBar: styled_components_dist_types.IStyledComponentBase<"web", styled_components.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
declare const MobileNavDrawer: styled_components_dist_types.IStyledComponentBase<"web", styled_components_dist_types.Substitute<react.DetailedHTMLProps<react.HTMLAttributes<HTMLElement>, HTMLElement>, {
    $open?: boolean;
}>> & string;

export { AppShell, AppSidebar, DashboardGrid, FieldGroup, FieldHint, FieldLabel, FilterBar, FormSection, InspectorLayout, ListDetailLayout, MobileNavDrawer, PageContent, PageHeader, PageHeaderRow, PageSubtitle, PageTitle, PageTitleBlock, Panel, PanelHeader, PanelHint, PanelTitle, SectionTitle, SettingsShell, SidebarFooter, SidebarNav, SidebarSection, SplitLayout, SplitPanelShell, Toolbar, TopBar };
