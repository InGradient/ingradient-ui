/**
 * Environment-aware logger — debug/log calls are no-ops in production builds.
 * Detects dev mode from either Vite (`import.meta.env.DEV`) or Node-shaped
 * environments (`process.env.NODE_ENV === 'development'`).
 *
 * Usage:
 *   import { logger } from '@ingradient/ui'
 *   logger.debug('[MyModule]', 'verbose info', data)
 *   logger.warn('[MyModule]', 'something fishy', err)
 */
declare const logger: {
    debug: (..._args: unknown[]) => void;
    log: (..._args: unknown[]) => void;
    info: (...data: any[]) => void;
    warn: (...data: any[]) => void;
    error: (...data: any[]) => void;
};

export { logger };
