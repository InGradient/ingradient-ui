export { b as buttonAccent, a as buttonDanger, c as buttonDangerSecondary, d as buttonPrimary, e as buttonSecondary, f as controlField, s as surfaceCard, g as surfacePanel, h as surfaceRaised, i as surfaceRounded } from './buttons-CsntCuGx.js';
export { a as appShell, h as headerSurface, p as pageContentLayout, b as pageHeaderSurface } from './patterns-CvIAZkYq.js';
export { S as StatusTone, a as alertToneStyles, c as chartPalette, s as statusToneStyles } from './charts-9G47m4fy.js';
import * as react_jsx_runtime from 'react/jsx-runtime';
import * as react from 'react';
import react__default from 'react';
import * as styled_components from 'styled-components';

declare const foundationColors: {
    readonly slate950: "#0f1115";
    readonly slate925: "#10151d";
    readonly slate900: "#111821";
    readonly slate880: "rgba(12, 15, 20, 0.88)";
    readonly slate860: "rgba(12, 15, 20, 0.8)";
    readonly slate840: "rgba(13, 18, 27, 0.92)";
    readonly white04: "rgba(255, 255, 255, 0.04)";
    readonly white06: "rgba(255, 255, 255, 0.06)";
    readonly white07: "rgba(255, 255, 255, 0.07)";
    readonly white08: "rgba(255, 255, 255, 0.08)";
    readonly white12: "rgba(255, 255, 255, 0.12)";
    readonly white18: "rgba(255, 255, 255, 0.18)";
    readonly white96: "rgba(255, 255, 255, 0.96)";
    readonly blue500: "#4d88ff";
    readonly blue600: "#2962d9";
    readonly blue300: "#8cb6ff";
    readonly blueTint12: "rgba(77, 136, 255, 0.12)";
    readonly blueTint14: "rgba(77, 136, 255, 0.14)";
    readonly blueTint16: "rgba(77, 136, 255, 0.16)";
    readonly blueTint18: "rgba(77, 136, 255, 0.18)";
    readonly blueTint28: "rgba(77, 136, 255, 0.28)";
    readonly blueTint38: "rgba(91, 144, 255, 0.38)";
    readonly blueTint42: "rgba(77, 136, 255, 0.42)";
    readonly green500: "#35c6a7";
    readonly greenTint12: "rgba(43, 181, 114, 0.12)";
    readonly greenTint18: "rgba(43, 181, 114, 0.18)";
    readonly amber500: "#ffd179";
    readonly amberTint18: "rgba(251, 146, 60, 0.18)";
    readonly amberTint20: "rgba(255, 196, 61, 0.2)";
    readonly red300: "#ff9a9a";
    readonly redTint12: "rgba(239, 68, 68, 0.12)";
    readonly redTint18: "rgba(239, 68, 68, 0.18)";
    readonly cyanTint18: "rgba(56, 189, 248, 0.18)";
    readonly violet300: "#c084fc";
    readonly borderMuted: "rgba(148, 163, 184, 0.14)";
    readonly borderStrong: "rgba(148, 163, 184, 0.18)";
    readonly overlayBackdrop: "rgba(4, 8, 14, 0.72)";
    readonly radialA: "rgba(66, 139, 202, 0.18)";
    readonly radialB: "rgba(0, 158, 115, 0.12)";
    readonly textPrimary: "#edf2f7";
    readonly textSecondary: "#d7deea";
    readonly textMuted: "#98a2b3";
    readonly textSoft: "#708196";
    readonly textSuccess: "#9ef0c1";
    readonly textWarning: "#ffe08a";
    readonly textDanger: "#fca5a5";
    readonly textInfo: "#cfe0ff";
    readonly textSuccessSoft: "#b7f6d1";
    readonly textWarningSoft: "#ffd6a5";
    readonly textDangerSoft: "#fecaca";
    readonly textCyan: "#8fe6ff";
    readonly textBlue: "#a9c6ff";
    readonly textSlate: "#cbd5e1";
    readonly textSlateSoft: "#d5dee9";
    readonly textOrange: "#fdba74";
};

declare const spacingScale: {
    readonly 0: "0px";
    readonly 1: "4px";
    readonly 2: "6px";
    readonly 3: "8px";
    readonly 4: "10px";
    readonly 5: "12px";
    readonly 6: "14px";
    readonly 7: "16px";
    readonly 8: "18px";
    readonly 9: "20px";
    readonly 10: "22px";
    readonly 11: "24px";
    readonly 12: "28px";
    readonly 13: "32px";
};

declare const radiusScale: {
    readonly xs: "10px";
    readonly sm: "12px";
    readonly md: "14px";
    readonly lg: "16px";
    readonly xl: "18px";
    readonly '2xl': "20px";
    readonly '3xl': "22px";
    readonly '4xl': "24px";
    readonly pill: "999px";
};

declare const typographyScale: {
    readonly fontSans: "\"IBM Plex Sans\", \"Segoe UI\", sans-serif";
    readonly fontMono: "\"IBM Plex Mono\", \"SFMono-Regular\", Consolas, monospace";
    readonly size2xs: "11px";
    readonly sizeXs: "12px";
    readonly sizeSm: "13px";
    readonly sizeMd: "14px";
    readonly sizeLg: "15px";
    readonly sizeXl: "16px";
    readonly size2xl: "18px";
    readonly size3xl: "20px";
    readonly size4xl: "24px";
    readonly size5xl: "28px";
};

declare const shadowScale: {
    readonly panel: "0 20px 60px rgba(0, 0, 0, 0.25)";
    readonly floating: "0 30px 80px rgba(0, 0, 0, 0.45)";
    readonly popover: "0 24px 60px rgba(0, 0, 0, 0.34), inset 0 1px 0 rgba(255, 255, 255, 0.05)";
    readonly hoverLift: "0 12px 24px rgba(41, 98, 217, 0.24)";
    readonly focusRing: "0 0 0 3px rgba(77, 136, 255, 0.16)";
};

declare const motionScale: {
    readonly fast: "0.16s ease";
    readonly normal: "0.24s ease";
};

declare const breakpoints: {
    readonly sm: 640;
    readonly md: 768;
    readonly lg: 1024;
    readonly xl: 1280;
};
declare const media: {
    readonly sm: "@media (max-width: 640px)";
    readonly md: "@media (max-width: 768px)";
    readonly lg: "@media (max-width: 1024px)";
    readonly xl: "@media (max-width: 1280px)";
};

declare const zIndexScale: {
    readonly popover: 500;
    readonly drawer: 1100;
    readonly modal: 1200;
};

declare const controlSizes: {
    readonly sm: "32px";
    readonly md: "36px";
    readonly lg: "44px";
};

interface IngradientTheme {
    name: string;
    colors: {
        bgCanvas: string;
        bgCanvasAlt: string;
        bgRadialA: string;
        bgRadialB: string;
        surfaceHeader: string;
        surfacePanel: string;
        surfaceRaised: string;
        surfaceMuted: string;
        surfaceInteractive: string;
        surfaceActive: string;
        borderSubtle: string;
        borderStrong: string;
        textPrimary: string;
        textSecondary: string;
        textMuted: string;
        textSoft: string;
        accent: string;
        accentStrong: string;
        accentSoft: string;
        success: string;
        warning: string;
        danger: string;
    };
    radius: {
        sm: string;
        md: string;
        lg: string;
        xl: string;
        pill: string;
    };
    shadows: {
        panel: string;
        floating: string;
    };
    breakpoints: {
        sm: number;
        md: number;
        lg: number;
        xl: number;
    };
    motion: {
        fast: string;
        normal: string;
    };
    typography: {
        fontSans: string;
        fontMono: string;
    };
}

declare const ingradientTheme: IngradientTheme;
declare const themes: {
    portalDark: IngradientTheme;
};

/**
 * @deprecated --portal-* 레거시 CSS 변수 매핑.
 *
 * 2026-05-08 기준 ingradient-platform, ingradient-edge, @ingradient/ui 자체
 * 어디서도 var(--portal-*) 를 사용하지 않음 (D-5 마이그레이션 완료).
 *
 * 이 매핑은 더 이상 renderTokensCss() 출력에 포함되지 않으며, 외부 코드가
 * 이 export를 import해서 직접 emit하지 않는 한 런타임에 적용되지 않음.
 *
 * 다음 메이저 버전에서 파일 자체 삭제 예정. 새 코드는 var(--ig-color-*) 사용.
 */
declare const legacyPortalCssVariables: {
    readonly '--portal-bg-base': "var(--ig-color-bg-canvas)";
    readonly '--portal-bg-radial-a': "var(--ig-color-bg-radial-a)";
    readonly '--portal-bg-radial-b': "var(--ig-color-bg-radial-b)";
    readonly '--portal-surface-header': "var(--ig-color-surface-header)";
    readonly '--portal-surface-panel': "var(--ig-color-surface-panel)";
    readonly '--portal-surface-elevated': "var(--ig-color-surface-raised)";
    readonly '--portal-surface-muted': "var(--ig-color-surface-muted)";
    readonly '--portal-surface-interactive': "var(--ig-color-surface-interactive)";
    readonly '--portal-surface-active': "var(--ig-color-surface-active)";
    readonly '--portal-border': "var(--ig-color-border-subtle)";
    readonly '--portal-border-strong': "var(--ig-color-border-strong)";
    readonly '--portal-text-primary': "var(--ig-color-text-primary)";
    readonly '--portal-text-secondary': "var(--ig-color-text-secondary)";
    readonly '--portal-text-muted': "var(--ig-color-text-muted)";
    readonly '--portal-text-soft': "var(--ig-color-text-soft)";
    readonly '--portal-accent': "var(--ig-color-accent)";
    readonly '--portal-accent-strong': "var(--ig-color-accent-strong)";
    readonly '--portal-accent-soft': "var(--ig-color-accent-soft)";
    readonly '--portal-success': "var(--ig-color-success)";
    readonly '--portal-warning': "var(--ig-color-warning)";
    readonly '--portal-danger': "var(--ig-color-danger)";
    readonly '--portal-shadow': "var(--ig-shadow-panel)";
    readonly '--portal-scrollbar-thumb': "var(--ig-scrollbar-thumb)";
    readonly '--portal-scrollbar-thumb-hover': "var(--ig-scrollbar-thumb-hover)";
    readonly '--portal-scrollbar-thumb-active': "var(--ig-scrollbar-thumb-active)";
};

declare const tokenCssVariables: {
    readonly '--ig-color-bg-canvas': string;
    readonly '--ig-color-bg-canvas-alt': string;
    readonly '--ig-color-bg-radial-a': string;
    readonly '--ig-color-bg-radial-b': string;
    readonly '--ig-color-surface-header': string;
    readonly '--ig-color-surface-panel': string;
    readonly '--ig-color-surface-raised': string;
    readonly '--ig-color-surface-muted': string;
    readonly '--ig-color-surface-interactive': string;
    readonly '--ig-color-surface-active': string;
    readonly '--ig-color-border-subtle': string;
    readonly '--ig-color-border-strong': string;
    readonly '--ig-color-text-primary': string;
    readonly '--ig-color-text-secondary': string;
    readonly '--ig-color-text-muted': string;
    readonly '--ig-color-text-soft': string;
    readonly '--ig-color-accent': string;
    readonly '--ig-color-accent-strong': string;
    readonly '--ig-color-accent-soft': string;
    readonly '--ig-color-success': string;
    readonly '--ig-color-warning': string;
    readonly '--ig-color-danger': string;
    readonly '--ig-color-surface-card-a': "rgba(18, 21, 28, 0.96)";
    readonly '--ig-color-surface-card-b': "rgba(10, 14, 20, 0.96)";
    readonly '--ig-color-surface-interactive-hover': "rgba(255, 255, 255, 0.07)";
    readonly '--ig-color-surface-focus': "rgba(16, 22, 32, 0.98)";
    readonly '--ig-color-accent-ring': "rgba(91, 144, 255, 0.7)";
    readonly '--ig-color-accent-border-strong': "rgba(91, 144, 255, 0.38)";
    readonly '--ig-color-accent-soft-surface': "rgba(77, 136, 255, 0.12)";
    readonly '--ig-color-accent-soft-surface-hover': "rgba(77, 136, 255, 0.18)";
    readonly '--ig-color-inset-highlight': "rgba(255, 255, 255, 0.04)";
    readonly '--ig-radius-sm': string;
    readonly '--ig-radius-md': string;
    readonly '--ig-radius-lg': string;
    readonly '--ig-radius-xl': string;
    readonly '--ig-radius-pill': string;
    readonly '--ig-radius-xs': "10px";
    readonly '--ig-radius-sm-alt': "12px";
    readonly '--ig-radius-lg-alt': "16px";
    readonly '--ig-radius-2xl': "20px";
    readonly '--ig-radius-3xl': "22px";
    readonly '--ig-radius-4xl': "24px";
    readonly '--ig-shadow-panel': string;
    readonly '--ig-shadow-floating': string;
    readonly '--ig-shadow-popover': "0 24px 60px rgba(0, 0, 0, 0.34), inset 0 1px 0 rgba(255, 255, 255, 0.05)";
    readonly '--ig-shadow-hover-lift': "0 12px 24px rgba(41, 98, 217, 0.24)";
    readonly '--ig-shadow-focus-ring': "0 0 0 3px rgba(77, 136, 255, 0.16)";
    readonly '--ig-font-sans': string;
    readonly '--ig-font-mono': string;
    readonly '--ig-font-size-2xs': "11px";
    readonly '--ig-font-size-xs': "12px";
    readonly '--ig-font-size-sm': "13px";
    readonly '--ig-font-size-md': "14px";
    readonly '--ig-font-size-lg': "15px";
    readonly '--ig-font-size-xl': "16px";
    readonly '--ig-font-size-2xl': "18px";
    readonly '--ig-font-size-3xl': "20px";
    readonly '--ig-font-size-4xl': "24px";
    readonly '--ig-font-size-5xl': "28px";
    readonly '--ig-space-0': "0px";
    readonly '--ig-space-1': "4px";
    readonly '--ig-space-2': "6px";
    readonly '--ig-space-3': "8px";
    readonly '--ig-space-4': "10px";
    readonly '--ig-space-5': "12px";
    readonly '--ig-space-6': "14px";
    readonly '--ig-space-7': "16px";
    readonly '--ig-space-8': "18px";
    readonly '--ig-space-9': "20px";
    readonly '--ig-space-10': "22px";
    readonly '--ig-space-11': "24px";
    readonly '--ig-space-12': "28px";
    readonly '--ig-space-13': "32px";
    readonly '--ig-z-popover': string;
    readonly '--ig-z-drawer': string;
    readonly '--ig-z-modal': string;
    readonly '--ig-z-context-menu': "1000";
    readonly '--ig-z-tooltip': "9999";
    readonly '--ig-z-dropdown': "100";
    readonly '--ig-scrollbar-thumb': "rgba(148, 163, 184, 0.22)";
    readonly '--ig-scrollbar-thumb-hover': "rgba(148, 163, 184, 0.34)";
    readonly '--ig-scrollbar-thumb-active': "rgba(148, 163, 184, 0.42)";
    readonly '--ig-color-status-running-bg': "rgba(43, 181, 114, 0.18)";
    readonly '--ig-color-status-running-text': "#9ef0c1";
    readonly '--ig-color-status-completed-bg': "rgba(56, 189, 248, 0.18)";
    readonly '--ig-color-status-completed-text': "#8fe6ff";
    readonly '--ig-color-status-queued-bg': "rgba(77, 136, 255, 0.18)";
    readonly '--ig-color-status-queued-text': "#a9c6ff";
    readonly '--ig-color-status-draft-bg': "rgba(255, 196, 61, 0.2)";
    readonly '--ig-color-status-draft-text': "#ffe08a";
    readonly '--ig-color-status-failed-bg': "rgba(239, 68, 68, 0.18)";
    readonly '--ig-color-status-failed-text': "#fca5a5";
    readonly '--ig-color-status-stopped-bg': "rgba(148, 163, 184, 0.16)";
    readonly '--ig-color-status-stopped-text': "#d5dee9";
    readonly '--ig-color-status-interrupted-bg': "rgba(251, 146, 60, 0.18)";
    readonly '--ig-color-status-interrupted-text': "#fdba74";
    readonly '--ig-color-status-warning-bg': "rgba(251, 146, 60, 0.18)";
    readonly '--ig-color-status-warning-text': "#fdba74";
    readonly '--ig-color-status-idle-bg': "rgba(67, 76, 94, 0.22)";
    readonly '--ig-color-status-idle-text': "#cbd5e1";
    readonly '--ig-color-alert-info-bg': "rgba(77, 136, 255, 0.12)";
    readonly '--ig-color-alert-info-border': "rgba(77, 136, 255, 0.26)";
    readonly '--ig-color-alert-info-text': "#cfe0ff";
    readonly '--ig-color-alert-success-bg': "rgba(43, 181, 114, 0.12)";
    readonly '--ig-color-alert-success-border': "rgba(43, 181, 114, 0.26)";
    readonly '--ig-color-alert-success-text': "#b7f6d1";
    readonly '--ig-color-alert-warning-bg': "rgba(251, 146, 60, 0.12)";
    readonly '--ig-color-alert-warning-border': "rgba(251, 146, 60, 0.26)";
    readonly '--ig-color-alert-warning-text': "#ffd6a5";
    readonly '--ig-color-alert-danger-bg': "rgba(239, 68, 68, 0.12)";
    readonly '--ig-color-alert-danger-border': "rgba(239, 68, 68, 0.26)";
    readonly '--ig-color-alert-danger-text': "#fecaca";
    readonly '--ig-color-chart-1': "#4d88ff";
    readonly '--ig-color-chart-2': "#35c6a7";
    readonly '--ig-color-chart-3': "#ffd179";
    readonly '--ig-color-chart-4': "#ff9a9a";
    readonly '--ig-color-chart-5': "#8cb6ff";
    readonly '--ig-color-chart-6': "#c084fc";
    readonly '--ig-color-chart-grid': "rgba(255, 255, 255, 0.08)";
    readonly '--ig-color-badge-neutral': "rgba(255, 255, 255, 0.08)";
    readonly '--ig-color-badge-accent': "rgba(77, 136, 255, 0.18)";
    readonly '--ig-color-badge-success': "rgba(43, 181, 114, 0.18)";
    readonly '--ig-color-badge-warning': "rgba(251, 146, 60, 0.18)";
    readonly '--ig-color-badge-danger': "rgba(239, 68, 68, 0.18)";
    readonly '--ig-color-progress-track': "rgba(255, 255, 255, 0.08)";
    readonly '--ig-color-skeleton-start': "rgba(255, 255, 255, 0.06)";
    readonly '--ig-color-skeleton-mid': "rgba(255, 255, 255, 0.12)";
    readonly '--ig-color-image-card-hover-border': "rgba(77, 136, 255, 0.28)";
    readonly '--ig-color-image-card-selected-border': "rgba(77, 136, 255, 0.42)";
    readonly '--ig-color-image-card-selected-ring': "rgba(77, 136, 255, 0.18)";
    readonly '--ig-color-image-card-gradient-a': "rgba(77, 136, 255, 0.14)";
    readonly '--ig-color-image-card-gradient-b': "rgba(43, 181, 114, 0.12)";
    readonly '--ig-color-avatar-bg': "rgba(77, 136, 255, 0.18)";
    readonly '--ig-color-dropdown-trigger-shadow': "inset 0 1px 0 var(--ig-color-inset-highlight), 0 10px 24px rgba(0, 0, 0, 0.12)";
    readonly '--ig-color-dropdown-open-shadow': "0 0 0 3px rgba(77, 136, 255, 0.16), 0 18px 36px rgba(0, 0, 0, 0.18)";
    readonly '--ig-color-dropdown-chevron-bg': "rgba(255, 255, 255, 0.04)";
    readonly '--ig-color-dropdown-chevron-border': "rgba(148, 163, 184, 0.14)";
    readonly '--ig-color-dropdown-menu-a': "rgba(18, 24, 34, 0.98)";
    readonly '--ig-color-dropdown-menu-b': "rgba(10, 14, 20, 0.98)";
    readonly '--ig-color-dropdown-option-hover': "rgba(255, 255, 255, 0.06)";
    readonly '--ig-color-toggle-on-bg': "rgba(77, 136, 255, 0.4)";
    readonly '--ig-color-toggle-on-border': "rgba(77, 136, 255, 0.55)";
    readonly '--ig-color-toggle-off-bg': "rgba(255, 255, 255, 0.12)";
    readonly '--ig-color-toggle-off-border': "rgba(148, 163, 184, 0.18)";
    readonly '--ig-color-tab-surface': "rgba(255, 255, 255, 0.04)";
    readonly '--ig-color-tab-highlight': "rgba(77, 136, 255, 0.18)";
    readonly '--ig-color-toolbar-surface': "rgba(8, 12, 18, 0.84)";
    readonly '--ig-color-modal-backdrop': "rgba(4, 8, 14, 0.72)";
    readonly '--ig-color-white-04': "rgba(255, 255, 255, 0.04)";
    readonly '--ig-color-white-06': "rgba(255, 255, 255, 0.06)";
    readonly '--ig-color-white-07': "rgba(255, 255, 255, 0.07)";
    readonly '--ig-color-white-08': "rgba(255, 255, 255, 0.08)";
    readonly '--ig-color-white-12': "rgba(255, 255, 255, 0.12)";
    readonly '--ig-color-white-18': "rgba(255, 255, 255, 0.18)";
    readonly '--ig-color-white-96': "rgba(255, 255, 255, 0.96)";
    readonly '--ig-color-blue-tint-12': "rgba(77, 136, 255, 0.12)";
    readonly '--ig-color-blue-tint-14': "rgba(77, 136, 255, 0.14)";
    readonly '--ig-color-blue-tint-16': "rgba(77, 136, 255, 0.16)";
    readonly '--ig-color-blue-tint-18': "rgba(77, 136, 255, 0.18)";
    readonly '--ig-color-blue-tint-28': "rgba(77, 136, 255, 0.28)";
    readonly '--ig-color-blue-tint-38': "rgba(91, 144, 255, 0.38)";
    readonly '--ig-color-blue-tint-42': "rgba(77, 136, 255, 0.42)";
    readonly '--ig-control-height-sm': "32px";
    readonly '--ig-control-height-md': "36px";
    readonly '--ig-control-height-lg': "44px";
};

declare function renderVariableBlock(selector: string, variables: Record<string, string>): string;
declare function renderTokensCss(): string;

declare function IngradientThemeProvider({ children, theme, }: {
    children: react__default.ReactNode;
    theme?: IngradientTheme;
}): react_jsx_runtime.JSX.Element;

declare const IngradientGlobalStyle: react.NamedExoticComponent<styled_components.ExecutionProps & object>;

export { IngradientGlobalStyle as DesignSystemGlobalStyle, IngradientGlobalStyle, type IngradientTheme, IngradientThemeProvider, IngradientGlobalStyle as PortalGlobalStyle, IngradientThemeProvider as ThemeProvider, breakpoints, controlSizes, foundationColors, ingradientTheme, legacyPortalCssVariables, media, motionScale, radiusScale, renderTokensCss, renderVariableBlock, shadowScale, spacingScale, themes, tokenCssVariables, typographyScale, zIndexScale };
