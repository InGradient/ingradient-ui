import * as styled_components from 'styled-components';

declare const surfacePanel: styled_components.RuleSet<object>;
declare const surfaceRaised: styled_components.RuleSet<object>;
declare const surfaceCard: styled_components.RuleSet<object>;
declare const surfaceRounded: styled_components.RuleSet<object>;

declare const controlField: styled_components.RuleSet<object>;

declare const buttonPrimary: styled_components.RuleSet<object>;
declare const buttonSecondary: styled_components.RuleSet<object>;
declare const buttonAccent: styled_components.RuleSet<object>;
declare const buttonDanger: styled_components.RuleSet<object>;
declare const buttonDangerSecondary: styled_components.RuleSet<object>;

export { buttonDanger as a, buttonAccent as b, buttonDangerSecondary as c, buttonPrimary as d, buttonSecondary as e, controlField as f, surfacePanel as g, surfaceRaised as h, surfaceRounded as i, surfaceCard as s };
